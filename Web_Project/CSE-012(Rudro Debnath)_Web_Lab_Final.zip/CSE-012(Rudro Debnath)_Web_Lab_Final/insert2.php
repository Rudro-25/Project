<html> 
    
    <head>
    	<link rel="stylesheet" href="style.css">
    </head>
    
	<body>
	<center>
	<form class="pada" action="insert2_action.php" method="POST" enctype="multipart/form-data">
		<h3> Insert Any User Record</h3>
		Name 
		<input type="text" name="name"> <br> <br>
		Email
		<input type="text" name="email"> <br> <br>
		Phone
		<input type="text" name="phone"> <br> <br>
		Type
		<input type="int" name="type"> <br> <br>

		<input type="submit" value="Insert">
	
	</form>
</center>
	</body>

</html>