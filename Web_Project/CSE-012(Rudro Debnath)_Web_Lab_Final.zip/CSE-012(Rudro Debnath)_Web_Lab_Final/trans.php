<html>
    <head>
    	<link rel="stylesheet" href="style.css">
    </head>
	<body>
	<center>
	<form class="pada" action="trans_action.php" method="POST">
		<h3> Transaction</h3>

		Phone
		<input type="text" name="unit"> <br> <br>
		Amount
		<input type="text" name="month"> <br> <br>

		<input type="submit" value="Submit">
	
	</form>
</center>
	</body>

</html>