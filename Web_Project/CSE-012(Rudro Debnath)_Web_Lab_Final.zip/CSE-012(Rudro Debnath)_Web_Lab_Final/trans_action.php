<?php 
	include "config.php";
	
    echo "Payment Successfull";

?>