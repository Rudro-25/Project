<html> 
    
    <head>
    	<link rel="stylesheet" href="style.css">
    </head>
    
	<body>
	<center>
	<form class="pada" action="insert1_action.php" method="POST" enctype="multipart/form-data">
		<h3> Insert Any Meter Record</h3>
		Name 
		<input type="text" name="name">  <br/> <br/>

		<input type="submit" value="Insert">
	
	</form>
</center>
	</body>

</html>