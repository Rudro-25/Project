<html> 
    
    <head>
    	<link rel="stylesheet" href="style.css">
    </head>
    
	<body>
	<center>
	<form class="pada" action="insert_connection_action.php" method="POST" enctype="multipart/form-data">
		<h3> Insert New User Record</h3>
		Name 
		<input type="text" name="name"> <br> <br>
		Email 
		<input type="text" name="email"> <br> <br>

		<input type="submit" value="Insert">
	
	</form>
</center>
	</body>

</html>