<html>
    <head>
    	<link rel="stylesheet" href="style.css">
    </head>
	<body>
	<center>
	<form class="pada" action="c_box_action.php" method="POST">
		<h3> Insert Complain</h3>

		Enter Your Complain
		<input type="text" name="complain"> <br> <br>
		<input type="submit" value="Submit">
	
	</form>
</center>
	</body>

</html>