<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Document</title>
</head>
<body>
  <form class="" action="includes/login.include.php" method="POST">
    <table>
         <tr>
         <td> </td><td><label for="email">Log In</label></td>
        </tr> 
        <tr> </tr>
        <tr> </tr>
        <tr> </tr>
        <tr> </tr>
        <tr> </tr>
        <tr> </tr>
        <tr>
         <td><label for="email">Email</label></td>
         <td><input type="text" name="email" id="" placeholder="Enter your email"></td>
        </tr>
        <tr>
          <td><label for="phone">Phone</label></td>
          <td><input type="text" name="phone" id="" placeholder="Enter your phone"></td>
        </tr>
        <tr>
          <td> </td>
          <td> <button name="login-btn">Submit</button></td>
        </tr>
        <tr> </tr>
        <tr> </tr>
        <tr> </tr>
        <tr> </tr>
        <tr> </tr>
        <br/><br/><br/>
        <td> </td><td><label for="email">Login Credentials:</label></td>
        <tr>
          <td> Admin-> </td> <td> Email: rudro.cse5.bu@gmail.com</td><td>Phone: 01741960830</td>
        </tr>
        <tr>
          <td> Biller-> </td> <td> Email: rahat.cse5.bu@gmail.com</td><td>Phone: 01741960830</td>
        </tr>
        <tr>
         <td> Consumer-> </td> <td> Email: sourav.cse5.bu@gmail.com</td><td>Phone: 01741960830</td>
       </tr>
       <tr>
        <td> Manager-> </td> <td> Email: sayem.cse5.bu@gmail.com</td><td>Phone: 01741960830</td>
      </tr>
    </table>
  </form>
</body>
</html>