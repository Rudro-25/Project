<!DOCTYPE html>
<html>
<head>
	<title>User registraton system using PHP and Mysql</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
        <div class="header">
        	<h2>Register </h2>
        </div> 
</body>
</html>