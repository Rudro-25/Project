<!DOCTYPE html>
<body>
<center><h3>WELCOME TO THE RARE DRUG PAGE!</h3><br><br></center>
<center><h3>Please click one:</h3><br><br></center>
<center><a href="http://localhost/demo/adminoptions.php"><h3>1. ADMIN PANEL</h3></a></center>
<center><a href=""><h3>2. CUSTOMER PANEL</h3></a></center>
</body>
</html>