<?php
	echo "<center><h3>Welcome to the Admin Panel!</h3></center><br><br>";
?>
<!DOCTYPE html>
<body>
<center><h3>Please choose an option: <br><br></h3></center>
<center><a href="http://localhost/demo/input.php"><h4>1. ADD DRUGS</h4></a></center>
<center><a href="http://localhost/demo/druglist.php"><h4>2. SHOW DRUG LIST</h4></a></center>
</body>
</html>