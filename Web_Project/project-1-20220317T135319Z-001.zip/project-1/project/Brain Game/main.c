#include <stdio.h>
#include <stdlib.h>
#include<time.h>
#include<string.h>

#define MAXCHAR 100000

int choice, c_chk, gmt = 5, p;


int menu();
int sub_menu1();
int volume_1();
int volume_2();
int volume_3();
int volume_4();
int volume_5();
int End_menu(int n);


int main()
{
    printf("\tHello and welcome to the game:\n\n\tSo You Think You Can Do It?\n\n\n");

    int m_r, v_r, g_r;
    m_r = menu();
    if(m_r==0) return 0;

    else if(m_r==1)
    {
        v_r = volume_1();
        if(v_r == 0) return 0;
    }
    else if(m_r==2)
    {
        v_r = volume_2();
        if(v_r == 0) return 0;
    }
    else if(m_r==3)
    {
        v_r = volume_3();
        if(v_r == 0) return 0;
    }
    else if(m_r==4)
    {
        v_r = volume_4();
        if(v_r == 0) return 0;
    }
    else if(m_r==5)
    {
        v_r = volume_5();
        if(v_r == 0) return 0;
    }
    return 0;
}


int menu()
{
   int n, x;
   printf("1. Set Difficulty\n2. Exit\n");
   scanf("%d", &x);
   if(x==1)
   {
       printf("1. Hopper\n2. Titan\n3. Pangea\n4. Vulcan\n5. Jarvice\n");
       scanf("%d", &n);
       return n;
   }
   else return 0;
}


int sub_menu1()
{
    printf("Do you want to continue?\n0. Exit\n1. Continue\n");
    scanf("%d", &choice);
    if(choice == 0)
    {
        printf("\n");
        return 0;
    }
    else return 1;
}


int volume_1()
{
    p = 1;
    int point=0, ok=0, f=0, v;
    time_t strt, end;
    double d,  t1 = 5;
    char ans[MAXCHAR];
    FILE *fp, *fp1;
    char str[MAXCHAR], str1[MAXCHAR];
    char* filename = "Hopper.txt";
    fp = fopen(filename, "r");
    fp1 = fopen("ANS1.txt", "r");

    if (fp == NULL|| fp1 == NULL)
    {
        printf("Could not open file\n");
        return 0;
    }
    printf("You have to complete this within %d seconds\n", gmt);
    while (fgets(str, MAXCHAR, fp) != NULL)
    {
        fscanf(fp1,"%s",str1);

        printf("%s\n", str);
        strt = time(NULL);
        scanf("%s", ans);
        end = time(NULL);
        d = difftime(end,strt);
        if(d <= t1 ) ok = 1;
        else
        {
            ok = 0;
        }

        if(!strcmp(ans, str1))
        {
            if(ok == 1)
            {
                point+=10;
            }
            else
            {
                printf("Time Limit Excceeded. Level Failed.\n");
                c_chk = sub_menu1();
                if(c_chk==0)
                {
                    printf("\n");
                    return 0;
                }
            }
         }
         else
         {
             printf("Wrong Answer. Level Failed.\n");
             c_chk = sub_menu1();
             if(c_chk==0)
             {
                 printf("\n");
                 return 0;
             }
          }

     }
     fclose(fp);
     if(point == 100)
     {
          printf("\t\tCongratulation!\nYou passed the selected stage\n");
          c_chk = sub_menu1();
          if(c_chk==0)
          {
              printf("\n");
              f = 1;
          }
      }
      else
      {
           printf("\t\tSorry\nYou did not get enough points.\nYour current point is:%d.\nNeeded point: 100\nBetter luck next time.\n", point);
           c_chk = sub_menu1();
           if(c_chk==0)
           {
               printf("\n");
               f = 1;
           }
      }
      if (f == 1)
      {
          v = End_menu(p);
          if(v == 0) return 0;
      }
}



int volume_2()
{
    p = 2;
    int point=0, ok=0, f=0, v;
    time_t strt, end;
    double d,  t1 = 10;
    char ans[MAXCHAR];
    FILE *fp, *fp1;
    char str[MAXCHAR], str1[MAXCHAR];
    char* filename = "Titan.txt";
    fp = fopen(filename, "r");
    fp1 = fopen("ANS2.txt", "r");

    if (fp == NULL|| fp1 == NULL)
    {
        printf("Could not open file\n");
        return 0;
    }
    printf("You have to complete this within %d seconds\n", gmt+5);
    while (fgets(str, MAXCHAR, fp) != NULL)
    {
        fgets(str1, MAXCHAR, fp1);

        printf("%s\n", str);
        strt = time(NULL);
        scanf("%s", ans);
        end = time(NULL);
        d = difftime(strt, end);
        if(d <= t1 ) ok = 1;
        else
        {
            ok = 0;
        }

        if(strcmp(ans, str1))
        {
            if(ok == 1) point+=10;
            else
            {
                printf("Time Limit Excceeded. Level Failed.\n");
                c_chk = sub_menu1();
                if(c_chk==0)
                {
                    printf("\n");
                    return 0;
                }
            }
         }
         else
         {
             printf("Wrong Answer. Level Failed.\n");
             c_chk = sub_menu1();
             if(c_chk==0)
             {
                 printf("\n");
                 return 0;
             }
          }

     }
     fclose(fp);
     if(point >= 90)
     {
          printf("\t\tCongratulation!\nYou passed the selected stage\n");
          c_chk = sub_menu1();
          if(c_chk==0)
          {
              printf("\n");
              f=1;
          }
      }
      else
      {
           printf("\t\tSorry\nYou did not get enough points.\nYour current point is:%d.\nNeeded point: 90\nBetter luck next time.\n", point);
           c_chk = sub_menu1();
           if(c_chk==0)
           {
               printf("\n");
               f=1;
           }
      }
      if (f == 1)
      {
          v = End_menu(p);
          if(v == 0) return 0;
      }
}



int volume_3()
{
    p = 3;
    int point=0, ok=0, f=0, v;
    time_t strt, end;
    double d,  t1 = 15;
    char ans[MAXCHAR];
    FILE *fp, *fp1;
    char str[MAXCHAR], str1[MAXCHAR];
    char* filename = "Pangea.txt";
    fp = fopen(filename, "r");
    fp1 = fopen("ANS3.txt", "r");

    if (fp == NULL|| fp1 == NULL)
    {
        printf("Could not open file\n");
        return 0;
    }
    while (fgets(str, MAXCHAR, fp) != NULL)
    {
        fgets(str1, MAXCHAR, fp1);

        printf("You have to complete this within %d seconds\n", gmt+10);
        printf("%s\n", str);
        strt = time(NULL);
        scanf("%s", ans);
        end = time(NULL);
        d = difftime(strt, end);
        if(d <= t1 ) ok = 1;
        else
        {
            ok = 0;
        }

        if(strcmp(ans, str1))
        {
            if(ok == 1) point+=10;
            else
            {
                printf("Time Limit Excceeded. Level Failed.\n");
                c_chk = sub_menu1();
                if(c_chk==0)
                {
                    printf("\n");
                    return 0;
                }
            }
         }
         else
         {
             printf("Wrong Answer. Level Failed.\n");
             c_chk = sub_menu1();
             if(c_chk==0)
             {
                 printf("\n");
                 return 0;
             }
          }

     }
     fclose(fp);
     if(point >= 80)
     {
          printf("\t\tCongratulation!\nYou passed the selected stage\n");
          c_chk = sub_menu1();
          if(c_chk==0)
          {
              printf("\n");
              return 1;
          }
      }
      else
      {
           printf("\t\tSorry\nYou did not get enough points.\nYour current point is:%d.\nNeeded point: 80\nBetter luck next time.\n", point);
           c_chk = sub_menu1();
           if(c_chk==0)
           {
               printf("\n");
               return 1;
           }
      }
      if (f == 1)
      {
          v = End_menu(p);
          if(v == 0) return 0;
      }
}


int volume_4()
{
    p = 4;
    int point=0, ok=0, f=0, v;
    time_t strt, end;
    double d,  t1 = 17;
    char ans[MAXCHAR];
    FILE *fp, *fp1;
    char str[MAXCHAR], str1[MAXCHAR];
    char* filename = "Vulcan.txt";
    fp = fopen(filename, "r");
    fp1 = fopen("ANS4.txt", "r");

    if (fp == NULL|| fp1 == NULL)
    {
        printf("Could not open file\n");
        return 0;
    }
    while (fgets(str, MAXCHAR, fp) != NULL)
    {
        fgets(str1, MAXCHAR, fp1);

        printf("You have to complete this within %d seconds\n", gmt+12);
        printf("%s\n", str);
        strt = time(NULL);
        scanf("%s", ans);
        end = time(NULL);
        d = difftime(strt, end);
        if(d <= t1 ) ok = 1;
        else
        {
            ok = 0;
        }

        if(strcmp(ans, str1))
        {
            if(ok == 1) point+=10;
            else
            {
                printf("Time Limit Excceeded. Level Failed.\n");
                c_chk = sub_menu1();
                if(c_chk==0)
                {
                    printf("\n");
                    return 0;
                }
            }
         }
         else
         {
             printf("Wrong Answer. Level Failed.\n");
             c_chk = sub_menu1();
             if(c_chk==0)
             {
                 printf("\n");
                 return 0;
             }
          }

     }
     fclose(fp);
     if(point == 70)
     {
          printf("\t\tCongratulation!\nYou passed the selected stage\n");
          c_chk = sub_menu1();
          if(c_chk==0)
          {
              printf("\n");
              return 1;
          }
      }
      else
      {
           printf("\t\tSorry\nYou did not get enough points.\nYour current point is:%d.\nNeeded point: 70\nBetter luck next time.\n", point);
           c_chk = sub_menu1();
           if(c_chk==0)
           {
               printf("\n");
               return 1;
           }
      }
      if (f == 1)
      {
          v = End_menu(p);
          if(v == 0) return 0;
      }
}


int volume_5()
{
    p = 5;
    int point=0, ok=0, f=0, v;
    time_t strt, end;
    double d,  t1 = 15;
    char ans[MAXCHAR];
    FILE *fp, *fp1;
    char str[MAXCHAR], str1[MAXCHAR];
    char* filename = "Jarvice.txt";
    fp = fopen(filename, "r");
    fp1 = fopen("ANS5.txt", "r");

    if (fp == NULL|| fp1 == NULL)
    {
        printf("Could not open file\n");
        return 0;
    }
    printf("You have complete this within %d seconds\n", gmt+15);
    while (fgets(str, MAXCHAR, fp) != NULL)
    {
        fgets(str1, MAXCHAR, fp1);

        printf("%s\n", str);
        strt = time(NULL);
        scanf("%s", ans);
        end = time(NULL);
        d = difftime(strt, end);
        if(d <= t1 ) ok = 1;
        else
        {
            ok = 0;
        }

        if(strcmp(ans, str1))
        {
            if(ok == 1) point+=10;
            else
            {
                printf("Time Limit Excceeded. Level Failed.\n");
                c_chk = sub_menu1();
                if(c_chk==0)
                {
                    printf("\n");
                    return 0;
                }
            }
         }
         else
         {
             printf("Wrong Answer. Level Failed.\n");
             c_chk = sub_menu1();
             if(c_chk==0)
             {
                 printf("\n");
                 return 0;
             }
          }

     }
     fclose(fp);
     if(point >= 70)
     {
          printf("\t\tCongratulation!\nYou passed the selected stage\n");
          c_chk = sub_menu1();
          if(c_chk==0)
          {
              printf("\n");
              return 1;
          }
      }
      else
      {
           printf("\t\tSorry\nYou did not get enough points.\nYour current point is:%d.\nNeeded point: 70\nBetter luck next time.\n", point);
           c_chk = sub_menu1();
           if(c_chk==0)
           {
               printf("\n");
               return 1;
           }
      }
      if (f == 1)
      {
          v = End_menu(p);
          if(v == 0) return 0;
      }
}


int End_menu(int n)
{
    int g_r, f;
    printf("Do you want to return to main menu?\n1. Main menu\n2. End game\n");
    scanf("%d", &g_r);
    if(g_r == 1)
    {
        n = n + 1;
        if(n == 1)
        {
            f = volume_1();
        }
        if(n == 2)
        {
            f = volume_2();
        }
        if(n == 3)
        {
            f = volume_3();
        }
        if(n == 4)
        {
            f = volume_4();
        }
        if(n == 5)
        {
            f = volume_5();
        }
        if(f==0) return 0;
    }
    else if(g_r == 2) return 0;
}
