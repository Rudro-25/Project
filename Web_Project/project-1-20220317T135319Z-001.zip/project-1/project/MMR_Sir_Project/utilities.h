



#ifndef UTILITIES_H
#define UTILITIES_H

void strtolower(char *str);

#endif // UTILITIES_H

