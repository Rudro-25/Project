
package Shape;


public interface ShapeInteface {

	double area();
    double perimeter ();
	
}
