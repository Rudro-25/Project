package Shape;

public class Main {
	public static void main(String[] args) {
        ShapeAbs ss;
        ss = new Triangle(20,10);
        double s = ss.area();
        System.out.println("Area of Triangle: "+s);
        
        ss = new Triangle(20,10,30);
        s = ss.perimeter();
        System.out.println("Perimeter of Triangle: "+s);
        
        ShapeInteface ss2;
        ss2 = new Rectangle(40,50);
        s = ss2.area();
        System.out.println("Area of Rectangle: "+s);
        s = ss2.perimeter();
        System.out.println("Perimeter of Rectangle: "+s);
        
        Circle c = new Circle(5);
        s = c.area();
        System.out.println("Area of Circle: "+s);
        s = c.perimeter();
        System.out.println("Perimeter of Circle: "+s);
    }
	
}







