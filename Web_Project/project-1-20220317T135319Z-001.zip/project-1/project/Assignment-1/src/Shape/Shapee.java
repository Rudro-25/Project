package Shape;

public class Shapee {
	Shapee (int i, int j, int k)
    {
        Triangle t2 = new Triangle(i,j,k);
    }
    Shapee (int i, int j)
    {
        Triangle t1 = new Triangle(i,j);
        Rectangle r1 = new Rectangle(i,j);
    }
    Shapee (int k)
    {
        Circle c1 = new Circle(k);
    }

}
