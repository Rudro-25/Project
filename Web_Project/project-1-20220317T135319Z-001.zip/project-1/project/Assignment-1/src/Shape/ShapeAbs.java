package Shape;

public abstract class ShapeAbs {
	
	abstract double area();
    abstract double perimeter ();
    public void tnx()
    {
        System.out.println("Thank You.\n");
    }

}
