package Shape;


import static java.lang.Math.PI;

public class Circle {
    double j;
    Circle (double i)
    {
        j=i;
    }
    public double area ()
    {
        return PI*j*j;
    }
    public double perimeter ()
    {
        return PI*j*2;
    }
}
