package Shape;

public class Triangle extends ShapeAbs {
    public int h,b,k;
    Triangle(int i,int j)
    {
        h=i;
        b=j;
    }
    Triangle(int i,int j, int k)
    {
        h=i;
        b=j;
        this.k=k;
    }
    @Override 
    double area()
    {
        return 0.5*h*b;
    }
    @Override 
    double perimeter ()
    {
        return h+b+k;
    }
}

