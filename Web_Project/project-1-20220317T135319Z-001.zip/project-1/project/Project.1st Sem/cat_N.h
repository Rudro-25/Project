void cat_N()
{
	  printf("\n\t\t\t*******Romance*******\n");
	printf("\n\t\tBook Title: Pride And Prejudice\n");
 	printf("\t\tAuthor Name: Jane Austin\n");
 	printf("\t\tPrice: $18.57\n");
	
	printf("\n\t\tBook Title: Premer Golpo\n");
 	printf("\t\tAuthor Name: Humayun Ahmed\n");
 	printf("\t\tPrice: $4\n");
	
	printf("\n\t\tBook Title: Breaking Dawn\n");
 	printf("\t\tAuthor Name: Stephene Meyer\n");
 	printf("\t\tPrice: $13\n");
	
	printf("\n\t\tBook Title: The Fault in Our Stars\n");
 	printf("\t\tAuthor Name: John Green\n");
 	printf("\t\tPrice: $17.24\n");
	
	printf("\n\t\tBook Title: Me Before You\n");
 	printf("\t\tAuthor Name: Jojo Moyes\n");
 	printf("\t\tPrice: $11.00\n");
	
}
