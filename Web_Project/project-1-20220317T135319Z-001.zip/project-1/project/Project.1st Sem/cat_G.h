void cat_G()
{
	
	  printf("\n\t\t\t*******Decective Story*******\n");
	printf("\n\t\tBook Title: Murder On The Orient Experss\n");
 	printf("\t\tAuthor Name: Agatha Cristie\n");
 	printf("\t\tPrice: $10.57\n");
	
	printf("\n\t\tBook Title: Sherlock Holmes\n");
 	printf("\t\tAuthor Name: Sir Arther Conan Doyle\n");
 	printf("\t\tPrice: $71.36\n");
	
	printf("\n\t\tBook Title: The Big Sleep\n");
 	printf("\t\tAuthor Name: Raymond Chandler\n");
 	printf("\t\tPrice: $20\n");
	
	printf("\n\t\tBook Title: The Black Echo\n");
 	printf("\t\tAuthor Name: Michel Chonnelly\n");
 	printf("\t\tPrice: $18.24\n");
	
	printf("\n\t\tBook Title: The Thin Man\n");
 	printf("\t\tAuthor Name: Dashiell Hammett\n");
 	printf("\t\tPrice: $21.00\n");
	
}

