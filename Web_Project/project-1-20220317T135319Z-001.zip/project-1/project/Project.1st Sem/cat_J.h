
void cat_J()
{
	  printf("\n\t\t\t*******Drama*******\n");
	printf("\n\t\tBook Title: Romeo And Juliet\n");
 	printf("\t\tAuthor Name: \n");
 	printf("\t\tPrice: $4.57\n");
	
	printf("\n\t\tBook Title: Mackbeth\n");
 	printf("\t\tAuthor Name: \n");
 	printf("\t\tPrice: $16.36\n");
	
	printf("\n\t\tBook Title: Hamlet\n");
 	printf("\t\tAuthor Name: \n");
 	printf("\t\tPrice: $15\n");
	
	printf("\n\t\tBook Title: The Lovely Bones\n");
 	printf("\t\tAuthor Name: Alice Sebold\n");
 	printf("\t\tPrice: $13\n");
	
	printf("\n\t\tBook Title: Who's Afraid of Virginia Woolf?\n");
 	printf("\t\tAuthor Name: Edward Elbee\n");
 	printf("\t\tPrice: $21.00\n");
	
	
}
