void cat_F()
{
	  printf("\n\t\t\t*******Travel Books*******\n");
	printf("\n\t\tBook Title: Around The World in 80 Days\n");
 	printf("\t\tAuthor Name: Joules Verne\n");
 	printf("\t\tPrice: $48.57\n");
	
	printf("\n\t\tBook Title: The Great Railway Bazzar\n");
 	printf("\t\tAuthor Name: Paul Theroux\n");
 	printf("\t\tPrice: $30.36\n");
	
	printf("\n\t\tBook Title: Walk in The Woods\n");
 	printf("\t\tAuthor Name: Bill Bryson\n");
 	printf("\t\tPrice: $18\n");
	
	printf("\n\t\tBook Title: Vagabonding\n");
 	printf("\t\tAuthor Name: Rolf Plotts\n");
 	printf("\t\tPrice: $12.24\n");
	
	printf("\n\t\tBook Title: Deshe-Bideshe\n");
 	printf("\t\tAuthor Name: Sayed Mujtaba Ali\n");
 	printf("\t\tPrice: $9.00\n");
	
	
}

