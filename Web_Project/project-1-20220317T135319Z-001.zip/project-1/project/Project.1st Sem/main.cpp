                           //By Kazi Mafruha Haque
                           //Login Password is test123 
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
#include"member_info.h"
#include"book_info.h"
#include"loan_info.h"
#include"cat_A.h"
#include"cat_B.h"
#include"cat_C.h"
#include"cat_D.h"
#include"cat_E.h"
#include"cat_F.h"
#include"cat_G.h"
#include"cat_H.h"
#include"cat_I.h"
#include"cat_J.h"
#include"cat_K.h"
#include"cat_L.h"
#include"cat_M.h"
#include"cat_N.h"
#include"cat_O.h"
#include"cat_P.h"
#include"departmental_text_books/physics.h"
#include"departmental_text_books/chemistry.h"
#include"departmental_text_books/math.h"
#include"departmental_text_books/bangla.h"
#include"departmental_text_books/cse.h"
#include"departmental_text_books/public_add.h"
#include"departmental_text_books/botany.h"
#include"departmental_text_books/sociology.h"
#include"departmental_text_books/soil_science.h"
#include"departmental_text_books/english.h"

  
  
   int main()
{
	FILE *fp;
    char a[110][28];
    int i=0,s,j=0,k;
    fp=fopen("My Project.txt","r");
    while(fgets(a[i],28,fp))
    {
    	i++;
	}
	fclose(fp);
	printf("\t\t\t  _________________________________________\t\t\n");
	printf("\t\t\t  | _____________________________________ |\t\t\n");
	printf("\t\t\t  | |                                   | |\t\t\n");
	printf("\t\t\t  | |    LIBRARY MANAGEMENT SYSTEMS     | |\t\t\n");
	printf("\t\t\t  | |___________________________________| |\t\t\n");
	printf("\t\t\t  |_______________________________________|\t\t\n");
	printf("\t\t\t\t\n\nHello! Please Enter Your Class Roll\n");
 	while(scanf("%d",&s)!=EOF)
	 {
	  	if(s>0 && s<=i)
	 	{
	 	    for(j=2;j<strlen(a[s-1]);j++) 
	 	    {
	 		printf("%c",a[s-1][j]);
		    } 
	    	printf("\n");
	    	printf("Thank You!You May Proceed\n");
	        }
		else
		{
			printf("ENTER THE NEW NUMBER\n");
		}
		 int x,y,k;
     for(k=s;k<50;k++)
        {
                if(k) 
	             member_info();
	             printf("\n"); 	
	            printf("\t\t\t\tGood Job!\n\t\t\tNow Enter Your Password Please...\n");
	             char pwd[50],c;
                 char t[10]="test123";    //It's the login Password
                 int i = 0, done=0;
                 while(!done) 
	                {
                          c = getch();
                          switch(c) 
		                 {
                          case '\r':
                                       pwd[i] = '\0';
                                       done = 1;
                                       break;
                           case '\b':
                                        i--;
                                        fputs("\b \b",stdout);
                                         break;
                           default:
                                         pwd[i++] = c;
                                         putchar('*');
                         }
                   }
                   putchar('\n');
              fputs(pwd,stdout);
              if (strcmp(pwd,t)==0)
                  {
                       printf("\n\n\t\t\tWelcome!!\n");
                       printf("\t\t\tYou Are a Varified Member of Our Library\n");
                  }
              else
                 {
                       printf("\n\n\t\tSorry!You Entered an Invalid Password\n\n\t\t\t");
                       break;
                 }
	
	                book_info();
	                 printf("\nPlease Enter Any Catagory Number Between 1 to 16\n");
                     scanf("%d",&x);
                     if(x==1)
                     {
                           cat_A();
                            printf("\n\t\t\t\tNow Enter Your Chosen Subject\n");
                            scanf("%d",&y);
                             if(y==1)
                             cse();
                             else if(y==2)
                             physics();
                             else if(y==3)
                             chem();
                             else if(y==4)
                             math();
                             else if(y==5)
                             bangla();
                             else if(y==6)
                             english();
                             else if (y==7)
                              public_add();
                             else if(y==8)
                             botany();
                             else if (y==9)
                             sociology();
                             else if(y==10)
                             soil_science();
                        }  
                      if(x==2)
                    {
  	                    cat_B();
                     }
                      if(x==3)
                    {
   	                     cat_C();
	                }  
	                  if(x==4)
	                {
		                cat_D();
	                }
	                    if(x==5)
	                {
		              cat_E();
	                }
                    	if(x==6)
	               { 
		               cat_F();
	               }
	                  if(x==7)
	               {
		               cat_G();
	               }
	                if(x==8)
	                {
		               cat_H();
	                }
	                 if(x==9)
	                {
		               cat_I();
	                }
	                 if(x==10)
	                {
		               cat_J();
	                }
	                 if(x==11)
	                {
		               cat_K();
	                }
	                 if(x==12)
	                {
		                cat_L();
	                }
	                 if(x==13)
	                {
		               cat_M();
	                }
	                 if(x==14)
	                {
	                	cat_N();
	                }
                 	  if(x==16)
	                {
		                cat_P();
	                }
	loan_info();
	     break;
        }
        break;	
     }
     
	 return 0;	
 }
