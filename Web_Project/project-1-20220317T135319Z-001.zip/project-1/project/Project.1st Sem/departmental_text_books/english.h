 void english()
 {
 	printf("\n\t\tBook Title: English Writing Skills\n");
 	printf("\t\tAuthor Name: Prof Atul Haque,Prof Jahurul Islam,Dr Binoy Barman\n");
 	printf("\t\tPrice: 235 Taka\n");
 	
 	printf("\n\t\tBook Title: English Reading Skills\n");
 	printf("\t\tAuthor Name: Prof Atul Haque,Prof Jahurul Islam,Dr Binoy Barman\n");
 	printf("\t\tPrice: $3.50\n");
 	
 	printf("\n\t\tBook Title: Introduction to Poetry-Volume 1\n");
 	printf("\t\tAuthor Name: Prof M Mofizar Rahman\n");
 	printf("\t\tPrice: 295 Taka\n");
 	
 	printf("\n\t\tBook Title: Introduction to Poetry-Volume 2\n");
 	printf("\t\tAuthor Name: Prof Ataul Haque\n");
 	printf("\t\tPrice: $2.94\n");
 	
 	printf("\n\t\tBook Title: A Gateway to English Prose\n");
 	printf("\t\tAuthor Name: Prof Subodh Chandra Sinha,Prof Abdul Barik Sarder\n");
 	printf("\t\tPrice: $3.00\n");
 }

