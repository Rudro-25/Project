void math()
 {
    printf("\n\t\tBook Title: Undergraduate Algebra\n");
 	printf("\t\tAuthor Name: Serge Lang\n");
 	printf("\t\tPrice: $89\n");
 	
 	printf("\n\t\tBook Title: Discrete Mathematics:Elementary & Beyond\n");
 	printf("\t\tAuthor Name: L.Lovasz,J.Pelikan,K.Vesztergombi\n");
 	printf("\t\tPrice: $65\n");
 	
 	printf("\n\t\tBook Title: Geometry & Vector Calculus\n");
 	printf("\t\tAuthor Name: A.R.Vasishtha\n");
 	printf("\t\tPrice: $34\n");
 	
 	printf("\n\t\tBook Title: Textbook of Matrix Algebra\n");
 	printf("\t\tAuthor Name: Suddhendu Biswas\n");
 	printf("\t\tPrice: $20\n");
 	
 	printf("\n\t\tBook Title: Textbook of Integral Calculus\n");
 	printf("\t\tAuthor Name: A.K.Sharma\n");
 	printf("\t\tPrice: $18\n");
 	
 }
