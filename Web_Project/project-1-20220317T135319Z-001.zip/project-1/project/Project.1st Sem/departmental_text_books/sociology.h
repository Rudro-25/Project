void sociology()
{
    printf("\n\t\tBook Title: Barbaric Society\n");
 	printf("\t\tAuthor Name: Louis Henry Morgan\n");
 	printf("\t\tPrice: 298 Taka\n");
		
	printf("\n\t\tBook Title: Shamajik Gobeshona O Porishankhan Porichiti\n");
 	printf("\t\tAuthor Name: Md.Abdul Mannan\n");
 	printf("\t\tPrice: 255 Taka\n");
 	
 	printf("\n\t\tBook Title: Shomajchinta O Shomajtattik Motobad\n");
 	printf("\t\tAuthor Name: Prof Dr A.F.Imam Ali\n");
 	printf("\t\t\tPrice: 315 Taka\n");
 	
 	printf("\n\t\tBook Title: Shomajtotto\n");
 	printf("\t\tAuthor Name: Prof Dr A.F.Imam Ali\n");
 	printf("\t\tPrice: 230 Taka\n");
 	
 	printf("\n\t\tBook Title: Pujibader Shomajtotto\n");
 	printf("\t\tAuthor Name: Md.Badrul Alam Khan\n");
 	printf("\t\tPrice: 298 Taka\n");
	
	
}

