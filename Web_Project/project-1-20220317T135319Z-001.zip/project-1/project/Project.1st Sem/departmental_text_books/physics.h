void physics()
 {
 	printf("\n\t\tBook Title: University Physics with Modern Physics\n");
 	printf("\t\tAuthor Name: Young,Freedman & Lewis Ford\n");
 	printf("\t\tPrice: $280.61\n");
 	
 	printf("\n\t\tBook Title: Physics for Scientists & Engineers with Modern Physics\n");
 	printf("\t\tAuthor Name: Douglas C.Giancoli\n");
 	printf("\t\tPrice: $265.21\n");
 
    printf("\n\t\tBook Title: Fundamentals of Physics\n");
 	printf("\t\tAuthor Name: David Hallyday,Robert Resnick & Jeral Walker\n");
 	printf("\t\tPrice: 34.96$\n");
 	
 	printf("\n\t\tBook Title: Physics for Scientists & Engineers:-A Strategic Approach\n");
 	printf("\t\tAuthor Name: Randall D.Knight\n");
 	printf("\t\tPrice: 285$\n");
 	
 	printf("\n\t\tBook Title: The Feynman Lecturec for Physics\n");
 	printf("\t\tAuthor Name: Richard Feynman\n");
 	printf("\t\tPrice: 145.59$\n");
 }
 
