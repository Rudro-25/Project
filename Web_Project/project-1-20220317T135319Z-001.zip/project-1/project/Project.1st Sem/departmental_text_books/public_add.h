void public_add()
{
	printf("\n\t\tBook Title: Lok Proshashon Prekkhioto Bangladesh\n");
 	printf("\t\tAuthor Name: Anowara Mahmud\n");
 	printf("\t\tPrice: 340 Taka\n");
	
	printf("\n\t\tBook Title: Bangladesh Lok Proshashon\n");
 	printf("\t\tAuthor Name: Prof Dr Emazuddin Ahmad\n");
 	printf("\t\tPrice: 273 Taka\n");
 	
 	printf("\n\t\tBook Title: Lok Proshashon Sar\n");
 	printf("\t\tAuthor Name: Muhammad Shamsur Rahman\n");
 	printf("\t\tPrice: 213 Taka\n");
 	
 	printf("\n\t\tBook Title: Lok Proshashon Porichiti\n");
 	printf("\t\tAuthor Name: Prof Kafil Uddin Ahmed\n");
 	printf("\t\t\tPrice: 182 Taka\n");
 	
 	printf("\n\t\tBook Title: Bangladesh Lok Proshashon Kotipoy Proshongo\n");
 	printf("\t\tAuthor Name: Masuda Kamal\n");
 	printf("\t\tPrice: 182 Taka\n");
}
