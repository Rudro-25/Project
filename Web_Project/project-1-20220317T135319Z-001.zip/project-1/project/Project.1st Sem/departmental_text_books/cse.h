 void cse()
 {
 	printf("\n\t\tBook Title: Fundamentals of Computer\n" );
 	printf("\t\tAuthor Name: Balagurusamy\n");
 	printf("\t\tPrice:200 Taka\n");
 	
 	printf("\n\t\tBook Title: Programming in ANSI C\n");
 	printf("\t\tAuthor Name: Balagurusamy\n");
 	printf("\t\tPrice:325 Taka\n");
 	
 	printf("\n\t\tBook Title: Programming in Java\n");
 	printf("\t\tAuthor Name: Balagurusamy\n");
 	printf("\t\tPrice:400 Taka\n");
 	
 	printf("\n\t\tBook Title: Algorithms & Data Structures\n");
 	printf("\t\tAuthor Name: Kurt Mehlhorn,Peter Sanders\n");
 	printf("\t\tPrice:2495 Taka\n");
 	
 	printf("\n\t\tBook Title: Mastering HTML,CSS & Javascript Web Publishing\n");
 	printf("\t\tAuthor Name: Laura Lemay\n");
 	printf("\t\tPrice: 1500 Taka\n");
 }
 
