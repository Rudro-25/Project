void bangla()
 {
 	printf("\n\t\tBook Title: Bangladesher Itihash-Prothom Khondo\n");
 	printf("\t\tAuthor Name: Romeshchandra Majumder\n");
 	printf("\t\tPrice: 340 Taka\n");
 	
 	printf("\n\t\tBook Title: Shahitter Ruptotto O Olongker\n");
 	printf("\t\tAuthor Name: Shafiq Aftab\n");
 	printf("\t\tPrice: 90 Taka\n");
 	
 	printf("\n\t\tBook Title: Kabbototto-Onnesha\n");
 	printf("\t\tAuthor Name: Noren Biswas\n");
 	printf("\t\tPrice: 90 Taka\n");
 	
 	printf("\n\t\tBook Title: Shadhin Bangladesher Ovvudoyer Itihash\n");
 	printf("\t\tAuthor Name: Muntasir Mamun\n");
 	printf("\t\tPrice: 255 Taka\n");
 	
 	printf("\n\t\tBook Title: Srikrishnokirton\n");
 	printf("\t\tAuthor Name: Mahbubul Alam\n");
 	printf("\t\tPrice: 225 Taka\n");
 	
 }
