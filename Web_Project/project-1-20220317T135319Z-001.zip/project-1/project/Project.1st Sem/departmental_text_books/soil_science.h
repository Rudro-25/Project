void soil_science()
{
	printf("\n\t\tBook Title: Essential Soil Science:A Clear & Concise Introduction to Soil Science\n");
 	printf("\t\tAuthor Name: M.R>Ashman & G.Puri\n");
 	printf("\t\tPrice: $48.57\n");
	
	printf("\n\t\tBook Title: Soil in the Environment\n");
 	printf("\t\tAuthor Name: Daniel Hillel\n");
 	printf("\t\tPrice: $71.36\n");
	
	printf("\n\t\tBook Title: The Soil of Egypt\n");
 	printf("\t\tAuthor Name: El-Ramady\n");
 	printf("\t\tPrice:  1399 Taka\n");
	
	printf("\n\t\tBook Title: Crop Ecology\n");
 	printf("\t\tAuthor Name: Robert S.Loomis\n");
 	printf("\t\tPrice: $59.24\n");
	
	printf("\n\t\tBook Title: Erosion of Civilization\n");
 	printf("\t\tAuthor Name: David R.Montgomery\n");
 	printf("\t\tPrice: $21.00\n");
	
}
