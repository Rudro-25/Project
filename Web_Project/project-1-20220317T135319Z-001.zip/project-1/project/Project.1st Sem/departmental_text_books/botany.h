void botany()
{
	printf("\n\t\tBook Title: Higher Cryptogamas\n");
 	printf("\t\tAuthor Name: Md. Majidul Haque\n");
 	printf("\t\tPrice: 200 Taka\n");
	
	printf("\n\t\tBook Title: Gymnosperms,Paliobotany,Economic Botany & Ethnobotany\n");
 	printf("\t\tAuthor Name: Debashish Roy\n");
 	printf("\t\tPrice: 145 Taka\n");
	
	printf("\n\t\tBook Title: Adhunik Udvidh Rog Biggan\n");
 	printf("\t\tAuthor Name: Hafizur Rahman Mandal\n");
 	printf("\t\tPrice: 100 Taka\n");
 	
 	printf("\n\t\tBook Title: Udhvidh Pranroshayan\n");
 	printf("\t\tAuthor Name: Saha,Basu\n");
 	printf("\t\tPrice: 341 Taka\n");
 	
 	printf("\n\t\tBook Title: Poribesh Roshayan\n");
 	printf("\t\tAuthor Name: Narayan Chandra Mahaldar\n");
 	printf("\t\tPrice: 291 Taka\n");
	
}

