 void chem()
 {
 	
 	printf("\n\t\tBook Title: Essentials of Physical Chemistry\n");
 	printf("\t\tAuthor Name: Arun Bahl,B.S Bahl & G.D Tuli\n");
 	printf("\t\tPrice: 1800 Taka\n");
 	
 	
 	printf("\n\t\tBook Title: Chemistry for Degree Students\n");
 	printf("\t\tAuthor Name: R L Madan\n");
 	printf("\t\tPrice: 1200 Taka\n");
 	
 	printf("\n\t\tBook Title: Physical Chemistry for The Chemical & Biological Sciences\n");
 	printf("\t\tAuthor Name: Raymond Chang\n");
 	printf("\t\tPrice: $112.63\n");
 	
 	printf("\n\t\t\tBook Title: Atkins' Physical Chemistry\n");
 	printf("\t\tAuthor Name: Peter Atkins & Julio De Paula\n");
 	printf("\t\t\tPrice: 1500 Taka\n");
 	
 	printf("\n\t\tBook Title: Organic Chemistry:-A Brief Course\n");
 	printf("\t\tAuthor Name: Robert Charles Atkins,Francis A. Carey\n");
 	printf("\t\tPrice: $185\n");
 }
 
