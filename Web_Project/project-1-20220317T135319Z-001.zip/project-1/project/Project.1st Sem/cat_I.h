void cat_I()
{
	  printf("\n\t\t\t*******Comics*******\n");
	printf("\n\t\tBook Title: The Adventures of Tintin\n");
 	printf("\t\tPrice: $8.57\n");
	
	printf("\n\t\tBook Title: Babu-Volume 11\n");
 	printf("\t\tAuthor Name: Shahriar\n");
 	printf("\t\tPrice: 100 Taka\n");
	
	printf("\n\t\tBook Title: Somor Mongol Ovijan\n");
 	printf("\t\tAuthor Name: Shahriar\n");
 	printf("\t\tPrice:  250 Taka\n");
	
	printf("\n\t\tBook Title: A Tale of Two Cities\n");
 	printf("\t\tAuthor Name: Charles Dickens\n");
 	printf("\t\tPrice: $10.24\n");
	
	printf("\n\t\tBook Title: The Death of Superman\n");
 	printf("\t\tAuthor Name: Dan Jurgens\n");
 	printf("\t\tPrice: $11.00\n");
}
