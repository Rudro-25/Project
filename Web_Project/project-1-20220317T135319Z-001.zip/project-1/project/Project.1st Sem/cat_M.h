void cat_M()
{
	  printf("\n\t\t\t*******Biography*******\n");
	printf("\n\t\tBook Title: The Diary of a Young Girl\n");
 	printf("\t\tAuthor Name: Anne Frank\n");
 	printf("\t\tPrice: $9\n");
	
	printf("\n\t\tBook Title: Steve Jobs\n");
 	printf("\t\tAuthor Name: Walter Issacson\n");
 	printf("\t\tPrice: $21.36\n");
	
	printf("\n\t\tBook Title: I Am Malala\n");
 	printf("\t\tAuthor Name: Malala Yousafzai\n"); 
 	printf("\t\tPrice: $6\n");
	
	printf("\n\t\tBook Title: Oshomapto Attojioboni\n");
 	printf("\t\tAuthor Name: Sheikh Mujibur Rahman\n");
 	printf("\t\tPrice: 400 Taka\n");
	
	printf("\n\t\tBook Title: Ekattorer Dinguli\n");
 	printf("\t\tAuthor Name: Jahanara Imam\n");
 	printf("\t\tPrice: $5.00\n");
	
}
