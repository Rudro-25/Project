void cat_P()
{
     printf("\n\t\t\t*******Poetry*******\n");
	printf("\n\t\tBook Title: Paradise Lost\n");
 	printf("\t\tAuthor Name: John Milton\n");
 	printf("\t\tPrice: $28.57\n");
	
	printf("\n\t\tBook Title: Leaves of Grass\n");
 	printf("\t\tAuthor Name: Wali Whitman\n");
 	printf("\t\tPrice: $21.36\n");
	
	printf("\n\t\tBook Title: Milk And Honey\n");
 	printf("\t\tAuthor Name: Rupi Kaur\n");
 	printf("\t\tPrice: $12\n");
	
	printf("\n\t\tBook Title: The Waste Land\n");
 	printf("\t\tAuthor Name: T.S.Eliot\n");
 	printf("\t\tPrice: $19.24\n");
	
	printf("\n\t\tBook Title: Iliad\n");
 	printf("\t\tAuthor Name: Homer\n");
 	printf("\t\tPrice: $35.00\n");
	   	
}
