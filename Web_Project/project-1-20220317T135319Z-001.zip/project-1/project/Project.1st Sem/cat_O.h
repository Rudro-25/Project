void cat_O()
{
	  printf("\n\t\t\t*******Mistry*******\n");
	printf("\n\t\tBook Title: The Lost Symbol\n");
 	printf("\t\tAuthor Name: Dan Brown\n");
 	printf("\t\tPrice: $22.57\n");
	
	printf("\n\t\tBook Title: The Girl on The Train\n");
 	printf("\t\tAuthor Name: Paula Hawkins\n");
 	printf("\t\tPrice: $33.36\n");
	
	printf("\n\t\tBook Title: Before I Go To Sleep\n");
 	printf("\t\tAuthor Name: S.J.Watson\n");
 	printf("\t\tPrice: $30\n");
	
	printf("\n\t\tBook Title: Rahasya Samagra\n");
 	printf("\t\tAuthor Name: Sirshendu Mukherjee\n");
 	printf("\t\tPrice: $9.24\n");
	
	printf("\n\t\tBook Title: Baghbondi Misir Ali\n");
 	printf("\t\tAuthor Name: Humayun Ahmed\n");
 	printf("\t\tPrice: 350 Taka\n");
	
	
}
