void member_info()
{
	char ID[100],Title[5],F_Name[10],L_Name[10],AD1[20],AD2[20],DOB[20];
	int i,postcode;
	printf("\n");
	
	printf("Customer ID: ");
	scanf("%s",ID);
	
	printf("Title: ");
	scanf("%s",Title);
	
	printf("First Name: ");
	scanf("%s",F_Name);
	
	printf("Last Name: ");
	scanf("%s",L_Name); 
	
	printf("Date of Birth: ");
	scanf("%s",DOB);
	
	printf("Present Address: ");
	scanf("%s",AD1);
	
	printf("Permanent Address: ");
	scanf("%s",AD2);
	
	printf("Post Code: ");
	scanf("%d",&postcode);
	
	

	
}


