void cat_B()
{
  	printf("\n\t\t\t*******Novels*******\n");
	printf("\n\t\tBook Title: Anna Karenina\n");
 	printf("\t\tAuthor Name: Leo Tolstoy\n");
 	printf("\t\tPrice: $200\n");
	
	printf("\n\t\tBook Title: To Kill a Mokingbird\n");
 	printf("\t\tAuthor Name: Harper Lee\n");
 	printf("\t\tPrice: $80\n");
	
	printf("\n\t\tBook Title: One hundred Years of Solitude\n");
 	printf("\t\tAuthor Name: Gabriel Garcia Marquez\n");
 	printf("\t\tPrice: $19\n");
	
	printf("\n\t\tBook Title: A Passage to India\n");
 	printf("\t\tAuthor Name: E.M.Foster\n");
 	printf("\t\tPrice: $59.24\n");
	
	printf("\n\t\tBook Title: Invisible Man\n");
 	printf("\t\tAuthor Name: Ralph Ellison\n");
 	printf("\t\tPrice: $21.00\n");
	
	
}


