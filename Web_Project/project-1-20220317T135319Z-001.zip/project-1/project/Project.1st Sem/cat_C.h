void cat_C()
{
	  printf("\n\t\t\t*******History Books*******\n");
	printf("\n\t\tBook Title: War and Peace\n");
 	printf("\t\tAuthor Name: Leo Tolstoy\n");
 	printf("\t\tPrice: $360\n");
	
	printf("\n\t\tBook Title: Decline and Fall of The Roman Empire\n");
 	printf("\t\tAuthor Name: Edward Gibbon\n");
 	printf("\t\tPrice: $180.75\n");
	
	printf("\n\t\tBook Title: Istanbul:-City of Majesty\n");
 	printf("\t\tAuthor Name: Thomas Madden\n");
 	printf("\t\tPrice: $200\n");
	
	printf("\n\t\tBook Title: Venice:A new History\n");
 	printf("\t\tAuthor Name: Thomas F. Madden\n");
 	printf("\t\tPrice: $150\n");
	
	printf("\n\t\tBook Title:A History of Bangladesh\n");
 	printf("\t\tAuthor Name: Willeam Schendel\n");
 	printf("\t\tPrice: $30.00\n");
	
}

