void cat_K()
{
	  printf("\n\t\t\t*******Fantasy*******\n");
	printf("\n\t\tBook Title: The Lord of The Rings\n");
 	printf("\t\tAuthor Name: J.R.R.Tolkien\n");
 	printf("\t\tPrice: $22.57\n");
	
	printf("\n\t\tBook Title: Harry Potter And The Deathly Hallows\n");
 	printf("\t\tAuthor Name: J.K.Rowling\n");
 	printf("\t\tPrice: $21.36\n");
	
	printf("\n\t\tBook Title: A Game of Thrones\n");
 	printf("\t\tAuthor Name: George R.R.Martin\n");
 	printf("\t\tPrice: $15\n");
	
	printf("\n\t\tBook Title: The Hobbit\n");
 	printf("\t\tAuthor Name: J.R.R.Tolkien\n");
 	printf("\t\tPrice: $23\n");
	
	printf("\n\t\tBook Title: American Gods\n");
 	printf("\t\tAuthor Name: Neil Gaiman\n");
 	printf("\t\tPrice: $11.00\n");
	
	
}
