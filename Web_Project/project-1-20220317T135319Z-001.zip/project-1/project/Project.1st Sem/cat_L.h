void cat_L()
{
	  printf("\n\t\t\t*******Adventure*******\n");
	printf("\n\t\tBook Title: Treasure Island\n");
 	printf("\t\tAuthor Name: Robert Louis Stevenson\n");
 	printf("\t\tPrice: $8.57\n");
	
	printf("\n\t\tBook Title: The Da Vinci Code\n");
 	printf("\t\tAuthor Name: Dan Brown\n");
 	printf("\t\tPrice: $30\n");
	
	printf("\n\t\tBook Title: The Hunger Games\n");
 	printf("\t\tAuthor Name: Suzanne Collins\n");
 	printf("\t\tPrice: $12\n");
	
	printf("\n\t\tBook Title: The Three Musketeers\n");
 	printf("\t\tAuthor Name: Alexandre Dumas\n");
 	printf("\t\tPrice: $9.24\n");
	
	printf("\n\t\tBook Title: Divergent\n");
 	printf("\t\tAuthor Name: Veronica Roth\n");
 	printf("\t\tPrice: $21.00\n");
	
}
