void cat_H()
{
	  printf("\n\t\t\t*******Science Fiction*******\n");
	printf("\n\t\tBook Title: The Darwin Variant\n");
 	printf("\t\tAuthor Name: Keneth Johnson\n");
 	printf("\t\tPrice: $18.57\n");
	
	printf("\n\t\tBook Title: Shunno\n");
 	printf("\t\tAuthor Name: Humayun Ahmed\n");
 	printf("\t\tPrice: $5.36\n");
	
	printf("\n\t\tBook Title: Eron\n");
 	printf("\t\tAuthor Name: Muhammad Jafar Iqbal\n");
 	printf("\t\tPrice: 200 Taka\n");
	
	printf("\n\t\tBook Title: Fugitive Six\n");
 	printf("\t\tAuthor Name: Pittacus Lore\n");
 	printf("\t\tPrice: $11.24\n");
	
	printf("\n\t\tBook Title: The Girl With All The Gifts\n");
 	printf("\t\tAuthor Name: M.R.Carey\n");
 	printf("\t\tPrice: $11.00\n");
	
	
}
