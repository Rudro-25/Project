void cat_D()
{
	 
	  printf("\n\t\t\t*******Religious Books*******\n");
	printf("\n\t\tBook Title: Al-Quran\n");
 	printf("\t\tPrice: 2000 Taka\n");
	
	printf("\n\t\tBook Title: Bangla Tafsir Books\n");
 	printf("\t\tPrice: $30\n");
	
	printf("\n\t\tBook Title: Bible\n");
 	printf("\t\tPrice: $70\n");
	
	printf("\n\t\tBook Title: Bukhari Sharif\n");
 	printf("\t\tAuthor Name: Islamic Foundation\n");
 	printf("\t\tPrice: 5000 Taka\n");
	
	printf("\n\t\tBook Title: The Bhagavad Gita\n");
 	printf("\t\tPrice: $50.00\n");
	 
	
	
}

