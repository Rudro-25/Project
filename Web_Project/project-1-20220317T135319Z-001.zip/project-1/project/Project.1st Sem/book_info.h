void book_info()
{
 char ID[5],bookctagory[15],Title[20],Authorname[15],type[10];
 int price,c,k,d;
 printf("\n\t\tWelcome To Barisal University Book Library\n");
 printf("\n\t\t\t\tPress 1 To See The Book Catagory\n");
 scanf("%d",&d);

 LOOP:if(d==1)
 {
 	printf("[1]Catagory A-Reference Book\n\n");
 	
 	printf("[2]Catagory B-Novel\n\n");
 	
 	printf("[3]Catagory C-History\n\n");
 	
 	printf("[4]Catagory D-Religious\n\n");
 	
 	printf("[5]Catagory E-Short Story\n\n");
 	
 	printf("[6]Catagory F-Travel\n\n");
 	
	printf("[7]Catagory G-Detective Story\n\n");
	
	printf("[8]Catagogy H-Science Fiction\n\n");
	
	printf("[9]Catagory I-Comics\n\n");
	
	printf("[10]Catagory J-Drama\n\n");
	
	printf("[11]Catagory K-Fantasy\n\n");
	
	printf("[12]Catagory L-Adventure\n\n");
	
	printf("[13]Catagory M-Biography\n\n");
	
	printf("[14]Catagory N-Romance\n\n");
	
	printf("[15]Catagory O-Mystery\n\n");
	
	printf("[16]Catagory P-Poetry\n\n");
	
 }
 else
 {
 	printf("\t\t\t\tPlease Press 1 To Proceed Further\n");
 	scanf("%d",&d);
    goto LOOP;
 }
}


