void cat_A()
{
	int p,q;
	
	  printf("\n\t\t\t*******Sections of Depertmental Text Books*******\n");
	  
	  printf("\n\t\t\t\t\t\t[1]Computer Science & Engineering\n");
	  
	  printf("\n\t\t\t\t\t\t[2]Physics\n");
	  
	  printf("\n\t\t\t\t\t\t[3]Chemistry\n");
	  
	  printf("\n\t\t\t\t\t\t[4]Mathematics\n");
	  
	  printf("\n\t\t\t\t\t\t[5]Bangla\n");
	  
	  printf("\n\t\t\t\t\t\t[6]English\n");
	  
	  printf("\n\t\t\t\t\t\t[7]Public Administration\n");
	  
	  printf("\n\t\t\t\t\t\t[8]Botany\n");
	  
	  printf("\n\t\t\t\t\t\t[9]Sociology\n");
	  
	  printf("\n\t\t\t\t\t\t[10]Soil & Environmental Science\n");
	  
	  printf("\n\t\t\t\t\t\t[11]Geology & Mining\n");
	  
	  printf("\n\t\t\t\t\t\t[12]Mass Communication & Journalism\n");
	  
	  printf("\n\t\t\t\t\t\t[13]Law\n");
	  
	  printf("\n\t\t\t\t\t\t[14]Biochemistry & Biotechnology\n");
	  
	  printf("\n\t\t\t\t\t\t[15]Coastal Studies & Disaster Management\n");
	  
	  printf("\n\t\t\t\t\t\t[16]Philosophy\n");
	  
	  printf("\n\t\t\t\t\t\t[17]Economics\n");
	  
	  printf("\n\t\t\t\t\t\t[18]Political Science\n");
	  
	  printf("\n\t\t\t\t\t\t[19]Management Studies\n");
	  
	  printf("\n\t\t\t\t\t\t[20]Accounting & Information Systems\n");
	  
	  printf("\n\t\t\t\t\t\t[21]Marketing\n");
	  
	  printf("\n\t\t\t\t\t\t[22]Finance & Banking\n");
}
 


