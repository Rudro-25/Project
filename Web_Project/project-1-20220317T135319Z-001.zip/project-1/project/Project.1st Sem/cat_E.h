void cat_E()
{
	  printf("\n\t\t\t*******Short Story*******\n");
	printf("\n\t\tBook Title: Premer Golpo\n");
 	printf("\t\tAuthor Name: Humayun Ahmed\n");
 	printf("\t\tPrice: $8.57\n");
	
	printf("\n\t\tBook Title: Dubliners\n");
 	printf("\t\tAuthor Name: James Joyce\n");
 	printf("\t\tPrice: $7.36\n");
	
	printf("\n\t\tBook Title: Golposhomogro\n");
 	printf("\t\tAuthor Name: Muhammad Jafar Iqbal\n");
 	printf("\t\tPrice: 450 Taka\n");
	
	printf("\n\t\tBook Title: Tenth of December\n");
 	printf("\t\tAuthor Name: George Saunders\n");
 	printf("\t\tPrice: $10.24\n");
	
	printf("\n\t\tBook Title: Men Without Women\n");
 	printf("\t\tAuthor Name: Haruki Murakami\n");
 	printf("\t\tPrice: $5.00\n");
	
	
}
