#include<stdio.h>
#include<string.h>
int loan_info()
{
	char z[5],l[5],t[5];
	printf("\n\t\tWhich Book Do You Want To Borrow? Enter Book Title\n");
	printf("Book Title: ");
	scanf("%s",z);
	printf("Date Borrowed: ");
	scanf("%s",&l);
	printf("Date Returned: ");
	scanf("%s",&t);
	printf("Late Submission Fine: 50 Taka per week\n");
	printf("\t\t\t\tAre you sure of these conditions?  If Yes, press 'Yes', else press 'No'\n  ");
	char s[10];
	scanf("%s",s);
	if(strcmp(s,"Yes")==0)
	{
	printf("\t\t\tYour Book Borrowed Successfully.Have a Cup of Coffee and Enjoy the Book!");
    }
	else
	{
	return 0;
    }
}


