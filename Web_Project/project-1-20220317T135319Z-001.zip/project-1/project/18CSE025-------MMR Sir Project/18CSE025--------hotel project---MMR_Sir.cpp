
              
			  /*    *****PROJECT*****
			  
			  LANGUAGE :     C++
			  
			  Compiler ::    Dev c++ only
			  
			  
			  
			  Name:              Rudro Debnath
              Class Roll:        18CSE025
              Session:           2017-18
              Semester & Year :  1st,1st
              department:        Computer Science and Engineering

              */



#include<iostream>
using namespace std;
struct node
{
  int room_no;
  char name[50];
  int cell_no;
  int cnic_no;
  node *prev,*next;
};
class marian
{
    private:
        int counter,num,b;
        int from,vrom,orom;
        node *head;
        int choise,rom,day;
        int rup;
        int bill;
        int allot;
         
    public:
       marian()
       {
         counter=100;
         head=NULL;
         from=20;
         vrom=30;
         orom=50;
         rup=bill=0;
         allot=day=b=rom=num=choise=0;
          
                 
       }    
       void family_room()
       {
        cout<<"\n***WELCOM TO 1st floor for family Rooms...!***"<<endl;
        cout<<"\n\thow many rooms do you want for rent\t";
        cin>>rom;
        cout<<"\n\thow many days do you want to stay.\t";
        cin>>day;
        cout<<"\n\ttotall family rooms are (20)\n"<<endl;
        if(rom<=20)
        {
            a:
            day=day*3000;
            bill=day*rom;
            cout<<"\n\tyour bill is\t"<<bill<<endl;   
            cout<<"ROOM CAN BE allot"<<endl;
            cout<<"\n\tpress 1 for first allot"<<endl;
            cout<<"\n\tpress 2 for after allot"<<endl;
            cout<<"\n\tpress 3 for before allot"<<endl;
            cout<<"\n\tpress 4 for last allot"<<endl;
            cout<<"\nenter the choise";
            cin>>allot;
            if(allot==1)
           {
                while(rom!=0)
            {
                first_allot();
                from--;
                counter--;
                rom--;
            }
          
            cout<<"available Family Rooms are\t"<<from<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
            working();
             
          }
            
          else if(allot==2)
               {
                 while(rom!=0)
                {
                after_allot();
                from--;
                counter--;
                rom--;
            }
            cout<<"avaliable Family Rooms are\t"<<from<<endl;
            cout<<"Total avaliable Rooms are\t"<<counter<<endl;
               working();
             
            }
        else if(allot==3)
        {
             while(rom!=0)
                {
                before_allot();
                from--;
                counter--;
                rom--;
            }
            cout<<"available Family Rooms are\t"<<from<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();
        }
        else if(allot==4)
        {
             while(rom!=0)
                {
                last_allot();
                from--;
                counter--;
                rom--;
            }
            cout<<"available Family Rooms are\t"<<from<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();
        }
        else
        {
            cout<<"\n\tinvalid option"<<endl;
            goto a; 
        }
     
         
 }
        else
           {
            cout<<"\n\tFAMILY ROOMS ARE NOT AVALIABLE"<<endl;
           }
            
       
            
    }
 
 
            
        void vip_room()
       {
        cout<<"\n***WELCOM TO 2st floor for VIP Rooms...!***"<<endl;
        cout<<"\n\thow many rooms do you want for rent\t";
        cin>>rom;
        cout<<"\n\n\t****3000 per day rent for VIP room **********\n"<<endl;
        cout<<"\n\tHow many days do you want to saty...\t";
        cin>>day;   
        cout<<"\n\ttotall VIP rooms are (30)\t"<<endl;
        if(rom<=30)
        {
            c:
                day=day*3000;
                bill=day*rom;
                cout<<"\n\tyour bill is\t"<<bill<<endl;   
            cout<<"ROOM CAN BE allot"<<endl;
            cout<<"\n\tpress 1 for first allot"<<endl;
            cout<<"\n\tpress 2 for after allot"<<endl;
            cout<<"\n\tpress 3 for before allot"<<endl;
            cout<<"\n\tpress 4 for last allot"<<endl;
            cout<<"\nenter the choise";
            cin>>allot;
            if(allot==1)
             {
                while(rom!=0)
             {
                first_allot();
                vrom--;
                counter--;
                rom--;
            }
            cout<<"available vip Rooms are\t"<<vrom<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();
          }
            
          else if(allot==2)
               {
                 while(rom!=0)
                {
                after_allot();
                vrom--;
                counter--;
                rom--;
            }
            cout<<"available vip Rooms are\t"<<vrom<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();
             
            }
        else if(allot==3)
        {
             while(rom!=0)
                {
                before_allot();
                vrom--;
                counter--;
                rom--;
            }
            cout<<"available vip Rooms are\t"<<vrom<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();
        }
        else if(allot==4)
        {
             while(rom!=0)
                {
                last_allot();
                vrom--;
                counter--;
                rom--;
            }
            cout<<"available vip Rooms are\t"<<vrom<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();
        }
        else
        {
            cout<<"\n\tinvalid option"<<endl;
            goto c; 
        }   
    }
        else
        {
            cout<<"\n\t vip ROOMS ARE NOT AVALIABLE"<<endl;
        }
}
  void other_room()
       {
        cout<<"\n*********WELCOM!********"<<endl;
        cout<<"\n\thow many rooms do you want for rent\t";
        cin>>rom;
        cout<<"\n\thow many days do you want to saty\t";
        cin>>day;
        cout<<"\n\ttotall other rooms are (50)\t"<<endl;
        if(rom<=50)
        {
            d:
            day=day*3000;
            bill=day*rom;
            cout<<"\n\tyour bill is\t"<<bill<<endl;   
            cout<<"ROOM CAN BE allot"<<endl;
            cout<<"\n\tpress 1 for first allot"<<endl;
            cout<<"\n\tpress 2 for after allot"<<endl;
            cout<<"\n\tpress 3 for before allot"<<endl;
            cout<<"\n\tpress 4 for last allot"<<endl;
            cout<<"\nenter the choise";
            cin>>allot;
                if(allot==1)
             {
                while(rom!=0)
             {
                first_allot();
                orom--;
                counter--;
                rom--;
            }
            cout<<"available other Rooms are\t"<<orom<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();
           }
            
               else if(allot==2)
               {
                 while(rom!=0)
                {
                after_allot();
                orom--;
                counter--;
                rom--;
            }
            cout<<"available other Rooms are\t"<<orom<<endl;
            cout<<"Total available Rooms are\t"<<counter<<endl;
             working();         
            }
        else if(allot==3)
        {
             while(rom!=0)
                {
                before_allot();
                orom--;
                counter--;
                rom--;
            }
            cout<<"available other Rooms are\t"<<orom<<endl;
            cout<<"Total avaliable Rooms are\t"<<counter<<endl;
             working();
        }
        else if(allot==4)
        {
             while(rom!=0)
                {
                last_allot();
                orom--;
                counter--;
                rom--;
            }
            cout<<"available other Rooms are\t"<<orom<<endl;
            cout<<"Total avaliable Rooms are\t"<<counter<<endl;
             working();
        }
        else
        {
            cout<<"\n\t invalid option"<<endl;
            goto d; 
        }   
             
                 
             
             
    }
        else
        {
            cout<<"\n\t other ROOMS ARE NOT AVAILABLE"<<endl;
        }
         
}
      //** void r_bill()
      // {
        // x:
         // int rem;
        //  cout<<"\n\tFamily room per day rent is (1000)"<<endl;
        //  cout<<"\n\tVIP room per day rent is (3000)"<<endl;
        //  cout<<"\n\tother room per day rent is (500)"<<endl;
            //cout<<"\tpress 1 for family room"<<endl;
            //cout<<"\tpress 2 for VIP room"<<endl;
            //cout<<"\tpress 3 for other "<<endl;
            //cout<<"enter your choise!";
            //cin>>choise;
            //cout<<"enter the number of ranted rooms";
            //cin>>rom;
         // cout<<"\n\tenter the number of days:\t";
         // cin>>day;
        // if(choise==1)
         //{
          //  day=day*1000;
        //  bill=rom*day;
        //  cout<<"your bill is\t"<<bill<<endl;
        //  cout<<"\tpay your bill\t";
        //  cin>>rup;
        //  if(rup<bill)
        //  {
        //  cout<<"\n\tinsufficent Money!"<<endl;
            //goto START;
        //  visit_hillside();
        //  
        //  }
        //  else
        //  {
        //      cout<<"\tbill is paid"<<endl;
        //      rem=rup-bill;
        //      cout<<"\nyour remaining money is\t"<<rem;
        //      fimly_room();
        //      visit_hillside();
                 
        //  }
         //}
         //else if(choise==2)
         //{
            //"your bill is\t"<<bill<<endl;
            //cout<<"\tpay your bill\t";
            //cin>>rupday=day*3000;
            //bill=rom*day;
            //cout<<;
            //if(rup<bill)
            //{
            //cout<<"\n\tinsufficent Money!"<<endl;
        //goto START;
            //visit_hillside();
           // }
           // else
            //{
          //    
        //      cout<<"\tbill is paid"<<endl;
        //      rem=rup-bill;
        //      cout<<"\nyour remaining money is\t"<<rem;
        //      vip_room();
        //      visit_hillside();
        //  }
        //}
         //else if(choise==3)
          // {
            //rom=day*500;
            //bill=rom*day;
            //cout<<"\n\tyour bill is\t"<<bill<<endl;
            //cout<<"\n\tpay your bill\t\n";
            //cin>>rup;
             //if(rup<bill)
            //{
            //cout<<"\n\tinsufficent Money!"<<endl;
            //goto START;
            //visit_hillside();
           // }
            //else
            //{
                 
            //  cout<<"\n\tbill is paid"<<endl;
            //  rem=rup-bill;
            //  cout<<"\nyour remaining money is\t"<<rem;
            //  other_room();
            //  visit_hillside();
            //}
             
          //}
          //else
         // {
            //cout<<"invalid opetion"<<endl;
          //}
 
   //}
       void first_allot()
       {
        bool flag=false;
        node *newer=new node;
        cout<<"\n\tEnther name\t";
        cin>>newer->name;
        cout<<"\n\tEnter CNIC number\t";
        cin>>newer->cnic_no;
        cout<<"\n\tEnter the Room number\t";
        cin>>newer->room_no;
        newer->prev=NULL;
        newer->next=head;
        flag=true;
        if(head!=NULL)
        {
           head->prev=newer; 
        }
        if(flag!=false)
        {
            cout<<"\n\tRoom is allotted successfully!"<<endl;
        }
        else
        {
            cout<<"\n\tRoom is not allotted!"<<endl;
        }
       }
       void last_allot()
       {
        bool flag=false;
        if(head==NULL)
        {
          cout<<"\n\tHotel is empty"<<endl;
          cout<<"\n\tdo you want to allot first?(1 for yes 2 for No)";
          cin>>b;
          if(b==1)
          {
              first_allot();
                     
           }
           else
           {
            //goto START;
            visit_marian();
            }
      }
            else
            {
            node *search=head;
            while(search->next!=NULL)
            {
                search=search->next;
            }
            node *newer=new node;
            cout<<"\n\tEnther name\t";
            cin>>newer->name;
            cout<<"\n\t enter the Room number!\t";
            cin>>newer->room_no;
            cout<<"\n\tEnter CNIC number\t";
            cin>>newer->cnic_no;
            newer->next=NULL;
            search->next=newer;
            newer->prev=search;
            flag=true;
           }
         
        if(flag!=false)
        {
            cout<<"\n\tRoom is allotted successfully!"<<endl;
       }
       else
       {
        cout<<"\n\tRoom is not alloted!"<<endl;
       }
         
}
       void after_allot()
       {
        if(head==NULL)
        {
            cout<<"\n\tHotel is empty!";
            cout<<"\n\tdo you want to allot first?(1 for yes 2 for No)";
            cin>>b;
          if(b==1)
          {
          first_allot();
           }
           else
           {
            //goto START;
            visit_marian();
           }
       }
       else
       {
        bool flag=false;
        node *temp=head;
        node *p;
        node *newer=new node;
        cout<<"\n\tEnter the Room# after which you want to allot the room!";
        cin>>num;
        while(temp!=NULL)
        {
          if(temp->room_no==num)
          {     
            cout<<"\n\tEnther name\t";
            cin>>newer->name;
            cout<<"\n\t enter the Room number!\t";
            cin>>newer->room_no;
            cout<<"\n\tEnter CNIC number\t";
            cin>>newer->cnic_no;
            if(temp->next==NULL)
            {
              newer->next=temp->next;
              newer->prev=temp;
              p=temp->next;
              temp->next=newer;
              p->prev=newer;
              flag=true;    
            }
            else
            {
                newer->next=temp->next;
                newer->prev=temp;
                temp->next=newer;
                flag=true;
            }
             
         }
         temp=temp->next;
                     
        }
        if(flag!=false)
        {
         cout<<"\n\tRoom is allotted successfully!"<<endl;      
       }
       else
       {
        cout<<"\n\tRoom is not allotted"<<endl;
       }
       }
}
     void before_allot()
     {
        bool flag=false;
        if(head==NULL)
        {
            cout<<"\n\tHotel is empty!";
            cout<<"\n\tdo you want to allot first?(1 for yes 2 for No)";
            cin>>b;
            if(b==1)
             {
              first_allot();
                     
             }
          else
            {
              //goto START;
              visit_marian();
            }
             
         }
         else
         {
     
            cout<<"\n\tEnter the Room# before which you want to allot the room!";
            cin>>num;
            node *newer=new node;
            if(head->room_no==num)
            {
            cout<<"\n\tEnther name\t";
            cin>>newer->name;
            cout<<"\n\t enter the Room number!\t";
            cin>>newer->room_no;
            cout<<"\n\tEnter CNIC number\t";
            cin>>newer->cnic_no;
            newer->next=head;
            newer->prev=head->prev;
            head=newer;
            flag=true;
           }
           else
           {
            node *temp=head;
            node *p;
            cout<<"\n\tEnther name\t";
            cin>>newer->name;
            cout<<"\n\t enter the Room number!\t";
            cin>>newer->room_no;
            cout<<"\n\tEnter CNIC number\t";
            cin>>newer->cnic_no;
            while(temp!=NULL)
            {
                if(temp->room_no==num)
                {
                    newer->next=temp;
                    newer->prev=temp->prev;
                    p=temp->prev;
                    p->next=newer;
                    temp->prev=newer;
                    flag=true;
                   }
                   temp=temp->next;
               }
             
           }
         
             
         }
         if(flag!=false)
         {
            cout<<"\n\tRoom is allotted successfully!"<<endl;  
         }
         else
         {
            cout<<"\n\tRoom is not alloted!"<<endl;
         }
     }
     void del()
     {
        cout<<"\n\tenter the Room# which you want to deallocate!\t";
        cin>>num;
        if(head==NULL)
        {
           cout<<"\n\tHotel is empty!"<<endl;
           cout<<"\n\tpress 1 for main manu\n"<<endl;
           cout<<"\tpress 2 for exit\n"<<endl;
           cout<<"\n\tentet your choise\t";
           cin>>choise;
           if(choise==1)
            {
             working();
            }
            else
            {
            exit(0);
            }
         }
         node *temp=head;
         if(temp->room_no==num)
         {
            head=temp->next;
            head->prev=NULL;
         }
         else
         {
            node *p,*q;
            while(temp!=NULL)
            {
                if(temp->next==NULL)
                {
                    p=temp->prev;
                    p->next=NULL;
                 }
                 else
                 {
                    p=temp->prev;
                    q=temp->next;
                    p->next=q;
                    q->prev=p;
                 }
                 temp=temp->next;
             }
             
         }
          
     }
     void display()
     {
        if(head==NULL)
        {
          cout<<"\n\tHotel is empty!"<<endl;
          cout<<"\n\tpress 1 for main manu\n"<<endl;
          cout<<"\tpress 2 for exit\n"<<endl;
          cout<<"\n\tentet your choise\t";
          cin>>choise;
          if(choise==1)
          {
            working();
           }
           else
           {
            exit(0);
           }
         }
         else
         {
            node *temp=head;
            while(temp!=NULL)
            {
                cout<<"\n"<<temp->room_no<<endl;
                temp=temp->next;
             }
         }
     }
       void visit_marian()
       {
        START:
        cout<<"\t*****WELCOM TO MARIAN HOTEL*****\n\t"<<endl;
        cout<<"\t***1st floor for family Rooms...!***\n"<<endl;
        cout<<"\t***2nd floor for VIP Rooms...!***\n"<<endl;
        cout<<"\t***For others 3rd,4th and 5th floors are avaliable...!***\n"<<endl;
        cout<<"\t press 1 for Family room\n"<<endl;
        cout<<"\t press 2 for VIP room\n"<<endl;
        cout<<"\t press 3 for others...\n"<<endl;
        cout<<"\tENTER YOUR CHOISE!\t";
        cin>>choise;
        if(choise==1)
        {
            family_room();
             
             
        }
        else if(choise==2)
        {
            vip_room();
             
        }
        else if(choise==3)
        {
            other_room();
        }
        else
        {
            cout<<"\n\tinvalid opetion"<<endl;
            //goto START;
            visit_marian();
        }
       }
      void working()
      {
        cout<<"\n\t***********Main Manu************\n\t"<<endl;
        cout<<"\n\tpress 1 to visit the Marian hotel!\t"<<endl;
        cout<<"\n\tpress 2 to delete the record of the room\t"<<endl;
        cout<<"\n\tpress 3 to display the record of marian...\t"<<endl;
        cout<<"\n\tpress 4 for exit...\n\t"<<endl;
        cout<<"\n\tenter your choise!\n";
        cin>>choise;
        if(choise==1)
        {
            visit_marian();
          }
          else if(choise==2)
          {
            del();
          }
          else if(choise==3)
          {
            display();
          }
          else
          {
            exit(0);
            //cout<<"\n\tinvalid choise"<<endl;
             
          }
         
      }
        
};
int main()
{
    marian obj;
    obj.working();
     
}
