#include<stdio.h>
#include<string.h>

#define MAXCHAR 1000

int main()
{
    char ans[MAXCHAR];
    FILE *fp;
    char str[MAXCHAR];
    char* filename = "Primary.txt";

    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Could not open file %s",filename);
        return 0;
    }
    while (fgets(str, MAXCHAR, fp) != NULL)
    {
        printf("%s\n", str);
        strt = time(NULL);
        scanf("%s", ans);
        end = time(NULL);
    }
    fclose(fp);
    return 0;
}

