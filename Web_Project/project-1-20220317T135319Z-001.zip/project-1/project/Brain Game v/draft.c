    int x;
    scanf("%d", &x);
    if(x==1)
    {
        FILE *fp;
        fp = fopen("Primary.txt", "r");
    }
    else if(x==2)
    {
        FILE *fp;
        fp = fopen("Primary.txt", "r");
    }
    else if(x==3)
    {
        FILE *fp;
        fp = fopen("Primary.txt", "r");
    }
    else if(x==4)
    {
        FILE *fp;
        fp = fopen("Primary.txt", "r");
    }
    else if(x==5)
    {
        FILE *fp;
        fp = fopen("Primary.txt", "r");
    }
    else
    {
        printf("File does not exist.\n");

    }
