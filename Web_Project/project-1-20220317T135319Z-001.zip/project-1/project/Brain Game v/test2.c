#include<stdio.h>
#include<time.h>

int main()
{
    int i;
    time_t strt, end;
    double d;
    strt = time(NULL);
    for(i=1; i<101; i++){}
    end = time(NULL);
    //printf("%lf\n", difftime(strt, end));
    d = difftime(end, strt);
    printf("%lf\n", d);
    return 0;
}

