
package Forest;

abstract class AbstractBlack {
	abstract String getbName();
	abstract int getbNumber();
	abstract String getbAddress();
	abstract String getbAnimals();
	abstract String getbBirds();
	
}

class Black extends AbstractBlack {
	
	private String name = "Black Forest";
	private int number = 6009;
	private String address = "Germany, Schwarzwald";
	private String animals = "Badger, Beaver";
	private String birds = "Woodpe, pygmy owls, Western capercaillie";
	
	
	public String getbName() {
		return name;
	}
	public int getbNumber() {
		return number;
	}
	public String getbAddress() {
		return address;
	}
	public String getbAnimals() {
		return animals;
	}
	public String getbBirds() {
		return birds;
	}
	
}
