package Forest;

public class Main {
	
	
public static void main(String[] args) {
	    AbstractSundarbans s = new Sundarbans();
		AbstractAmazon a = new Amazon();
		AbstractBlack b = new Black();
		
		System.out.println("<<<<<  DIFFERENT FOREST IN  THE WORLD  >>>>>");
		System.out.println("       --------------------");
		
		System.out.println("");
		
		System.out.println("FOrest NO 1 ");
		System.out.println("");
		System.out.println("Name of the  forest: " + s.getsName());
		System.out.println("Total area in KM: " + s.getsNumber());
		System.out.println("Location: " + s.getsAddress());
		System.out.println("popular animals: " + s.getsAnimals());
		System.out.println("popular birds: " + s.getsBirds());
		
		
		System.out.println("");
		
		System.out.println("Forest No 2");
		System.out.println("");
        System.out.println("Name of the  forest: " + a.getaName());
		System.out.println("Total area in KM: " + a.getaNumber());
		System.out.println("Location: " + a.getaAddress());
		System.out.println("popular animals: " + a.getaAnimals());
		System.out.println("popular birds: " + a.getaBirds());
		
		
		System.out.println("");
		
		System.out.println("Forest No 3");
		System.out.println("");
		System.out.println("Name of the  forest: " + b.getbName());
		System.out.println("Total area in KM: " + b.getbNumber());
		System.out.println("Location: " + b.getbAddress());
		System.out.println("popular animals: " + b.getbAnimals());
		System.out.println("popular birds: " + b.getbBirds());
		
}

}
