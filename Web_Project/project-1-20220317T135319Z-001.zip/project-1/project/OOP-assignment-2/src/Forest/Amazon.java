
package Forest;

abstract class AbstractAmazon {
	abstract String getaName();
	abstract int getaNumber();
	abstract String getaAddress();
	abstract String getaAnimals();
	abstract String getaBirds();
	
}

class Amazon extends AbstractAmazon {
	
	private String name = "Amazon";
	private int number = 7000000;
	private String address = "Brazil, Peru, Colombia";
	private String animals = "Giant otter, Black caiman";
	private String birds = "Pionus, Hoatzin, Grey antbird";
	
	
	public String getaName() {
		return name;
	}
	public int getaNumber() {
		return number;
	}
	public String getaAddress() {
		return address;
	}
	public String getaAnimals() {
		return animals;
	}
	public String getaBirds() {
		return birds;
	}
	
}
