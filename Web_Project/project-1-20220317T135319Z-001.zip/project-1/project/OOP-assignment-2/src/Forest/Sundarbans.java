
package Forest;

abstract class AbstractSundarbans {
	abstract String getsName();
	abstract int getsNumber();
	abstract String getsAddress();
	abstract String getsAnimals();
	abstract String getsBirds();
	
	
}
	
	class Sundarbans extends AbstractSundarbans {
	
	private String name = "Sundarbans";
	private int number = 10000;
	private String address = "Khulna, mungla in BD, West bengal in India";
	private String animals = "Royal Bengal Tiger,chital, wild boar";
	private String birds = "mangrove whistler, small minivet, black hooriole";
	
	
	public String getsName() {
		return name;
	}
	public int getsNumber() {
		return number;
	}
	public String getsAddress() {
		return address;
	}
	public String getsAnimals() {
		return animals;
	}
	public String getsBirds() {
		return birds;
	}
	
  }

