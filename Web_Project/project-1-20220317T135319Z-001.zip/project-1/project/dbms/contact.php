<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Homepage design with html abd css</title>
	<link rel="stylesheet" href="style9.css">
</head>
<body>
	<header>
		<div class="wrapper">
			
			<ul class="nav-area">
				<li><a href="http://localhost/dbms/home.html">Home</a></li>
				<li><a href="http://localhost/dbms/about.php">About</a></li>
				<li><a href="http://localhost/dbms/admin.php">Admin</a></li>
				<li><a href="http://localhost/dbms/custom.php">Customers</a></li>
				<li><a href="http://localhost/dbms/news.php">News</a></li>
			</ul>
		</div>


    <h3><center><br><br><br>IF ANY KIND OF QUERY CONTACT WITH US</br>
    <h3><center><br><br>ADMIN CONTACT NUMBER</br>
    	 ----------------------------------</br></br>
    	RUDRO : 01741960830<br/>Email : rudro.cse5.bu@gmail.com</br></br>
    	TARIN : 01756748392<br/>Email : tarin.cse5.bu@gmail.com</br></br>
    	SUBAL : 01712345678<br/>Email : subal.cse5.bu@gmail.com</br></br>
    	Developed by</br>
    	Students Of Computer Science And Engineering</br>
        University of Barisal</br></br>
        THANKS FOR COMING !!</center></h3>

	</header>
</body>
</html>