<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	
	<link rel="stylesheet" href="style1.css">
</head>
<body>
	<header>
		<div class="wrapper">
			
			<ul class="nav-area">
				<li><a href="http://localhost/dbms/home.html">Home</a></li>
				<li><a href="http://localhost/dbms/about.php">About</a></li>
				<li><a href="http://localhost/dbms/admin.php">Admin</a></li>
				<li><a href="http://localhost/dbms/custom.php">Customers</a></li>
				<li><a href="http://localhost/dbms/news.php">News</a></li>
			</ul>
		</div>

		 <center><h3><br><br><br><br>Please choose option: <br><br></h3></center>
		 <center><a href="http://localhost/dbms/tarin1.php">
		 	<button>1. Tarin Pharmacy</button>
		 </a></br></br>

         <center><a href="http://localhost/dbms/ordr.php">
		 	<button>2. Order a drug</button>
		 </a></br></br>

         <a href="http://localhost/dbms/druglist.php">
		 	<button>3. Show All Drug.....</button>
		 </a>
		</center>
	</header>

   

</body>
</html>













