<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Homepage design with html abd css</title>
	<link rel="stylesheet" href="style1.css">
</head>
<body>
	<header>
		<div class="wrapper">
			<ul class="nav-area">
				<li><a href="http://localhost/dbms/home.html">Home</a></li>
				<li><a href="http://localhost/dbms/about.php">About</a></li>
				<li><a href="http://localhost/dbms/admin.php">Admin</a></li>
				<li><a href="http://localhost/dbms/custom.php">Customers</a></li>
				<li><a href="http://localhost/dbms/news.php">News</a></li>
			</ul>
		</div>

<center><h2><br><br><br><br>..</h2></center><br><br>
<center>Give the quantity how much you want to buy.</center><br><br>
<form action="connect4.php" method="POST">
<center>Quantity: <input type="int" name="quantity"><br><br></center>

<center><input type="submit" name="submit"></center>
</form>

	</header>
</body>
</html>