

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>
  <link rel="stylesheet" href="style1.css">
</head>
<body>
  <header>
    <div class="wrapper">
    <ul class="nav-area">
      <li><a href="http://localhost/dbms/home.html">Home</a></li>
      <li><a href="http://localhost/dbms/about.php">About</a></li>
      <li><a href="http://localhost/dbms/admin.php">Admin</a></li>
      <li><a href="http://localhost/dbms/custom.php">Customers</a></li>
      <li><a href="http://localhost/dbms/news.php">News</a></li>
    </ul>
		</div>
		<div class="ok">
			<div class="admin1-container">
				<a href="add-company.php">Add a Company</a>
				<a href="add-category.php">Add a Category</a>
				<a href="add-shop.php">Add a Shop</a>
				<a href="add-medicine.php">Add a Medicine</a>
			</div>
		</div>
	</header>
</body>
</html>











