<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Homepage design with html add css</title>
	<link rel="stylesheet" href="style1.css">
</head>
<body>
	<header>
		<div class="wrapper">
			<ul class="nav-area">
				<li><a href="http://localhost/dbms/home.html">Home</a></li>
				<li><a href="http://localhost/dbms/about.php">About</a></li>
				<li><a href="http://localhost/dbms/admin.php">Admin</a></li>
				<li><a href="http://localhost/dbms/custom.php">Customers</a></li>
				<li><a href="http://localhost/dbms/news.php">News</a></li>
			</ul>
		</div>

<center><h2><h2><br><br><br><br>DELETE DRUG</h2></center><br><br>
	<center>Please enter the drug id which you want to delete.</center><br><br>
<form action="connect1.php" method="POST">
<center>ID: <input type="int" name="id"><br><br></center>
<center><input type="submit" name="Submit"></center>
</form>


	</header>
</body>
</html>





