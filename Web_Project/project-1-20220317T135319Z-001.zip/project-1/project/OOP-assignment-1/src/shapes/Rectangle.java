package shapes;

import java.util.Scanner;

abstract class RectangleInput{
	abstract void rinput();
	abstract double rgetArea();
}
class Rectangle extends RectangleInput{
	Scanner s = new Scanner(System.in);
	
	private double area;
	void rinput() {
		double length,width;
		System.out.println("Please enter the length and width of a rectangle respectively: ");
		length = s.nextDouble();
		width = s.nextDouble();
		area = length*width;
	};
	public double rgetArea(){
		return area;
	}
}