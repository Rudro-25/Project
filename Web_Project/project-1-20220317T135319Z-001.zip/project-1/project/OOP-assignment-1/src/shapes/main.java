
package shapes;

import java.util.Scanner;


class main {
		
	public static void main(String[] args) {
		
		CircleInput c = new Circle();
		c.cinput();
		System.out.println("AREA OF CIRCLE: " + c.cgetArea());
		
		TriangleInput t = new Triangle();
		t.tinput();
		System.out.println("AREA OF TRIANGLE: " + t.tgetArea());
		
		RectangleInput r = new Rectangle();
		r.rinput();
		System.out.println("AREA OF RECTANGLE: " + r.rgetArea());
	}

}
