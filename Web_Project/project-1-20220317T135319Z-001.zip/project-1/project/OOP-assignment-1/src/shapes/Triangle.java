package shapes;

import java.util.Scanner;

abstract class TriangleInput{
	abstract void tinput();
	abstract double tgetArea();
}
class Triangle extends TriangleInput{
	Scanner s = new Scanner(System.in);
	
	private double area;
	void tinput() {
		double base,height;
		System.out.println("Please enter the base and height of a triangle respectively: ");
		base = s.nextDouble();
		height = s.nextDouble();
		area = 0.50*base*height;
	};
	public double tgetArea(){
		return area;
	}
}