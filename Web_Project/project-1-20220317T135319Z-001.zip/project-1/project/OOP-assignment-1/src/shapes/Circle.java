
package shapes;

import java.util.Scanner;

abstract class CircleInput{
	abstract void cinput();
	abstract double cgetArea();
}
class Circle extends CircleInput{
	Scanner s = new Scanner(System.in);
	
	double pi = 3.14;
	private double area;
	void cinput() {
		double rad;
		System.out.println("Please enter the radius of a circle: ");
		rad = s.nextDouble();
		area = pi*rad*rad;
	};
	public double cgetArea(){
		return area;
	}
}
