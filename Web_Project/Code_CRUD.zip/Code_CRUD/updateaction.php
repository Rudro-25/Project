<?php 
	include "dbconnect.php";
	
	$id=$_GET['edit_id'];
	
	$uname=$_POST['name'];
	$roll=$_POST['roll'];
	$phone=$_POST['phone'];
	$add=$_POST['address'];
	
	$q="UPDATE student SET name='$uname', roll='$roll', phone='$phone',
	address='$add' WHERE id='$id'";
	$result=$connect->query($q);
	
	if($result)
	header('location:index.php');

?>