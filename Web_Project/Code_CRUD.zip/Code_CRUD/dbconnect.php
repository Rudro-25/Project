<?php
$hostname="localhost";
$uname="root";
$pwd="";
$db="crud";
$connect= new mysqli($hostname,$uname, $pwd, $db );

?>