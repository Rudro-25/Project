<?php
include "dbconnect.php";
$id=$_GET["editid"];
$q="SELECT * FROM student WHERE id='$id'";
$result=$connect->query($q);
$r=$result->fetch_assoc();

$nam=$r['name'];
$rol=$r['roll'];
$phon=$r['phone'];
$add=$r['address'];

?>

<html>
	<body>
	<center>
	<h1> Insert Student Info</h1>
	<form action="updateaction.php?edit_id= <?php echo $id;?>" method="POST">
		Name
		<input type="text" name="name" value="<?php echo $nam ?>"> <br> <br>
		Roll
		<input type="text" name="roll" value="<?php echo $rol ?>"> <br> <br>
		Phone
		<input type="text" name="phone" value="<?php echo $phon ?>"> <br> <br>
		Address
		<input type="text" name="address" value="<?php echo $add ?>"> <br> <br>
		<input type="submit" value="Update">
	
	</form>
</center>
	</body>

</html>