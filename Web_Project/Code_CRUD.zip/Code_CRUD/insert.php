<html>
	<body>
	<center>
	<h1> Insert Student Info</h1>
	<form action="insertaction.php" method="POST">
		Name
		<input type="text" name="name"> <br> <br>
		Roll
		<input type="text" name="roll"> <br> <br>
		Phone
		<input type="text" name="phone"> <br> <br>
		Address
		<input type="text" name="address"> <br> <br>
		<input type="submit" value="Insert">
	
	</form>
</center>
	</body>

</html>