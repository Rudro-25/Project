<?php 
	include "dbconnect.php";
	$uname=$_POST["name"];
	$roll=$_POST["roll"];
	$phone=$_POST["phone"];
	$add=$_POST["address"];
	
	$q="INSERT INTO student(id, name, roll, phone, address)
	VALUES('', '$uname', '$roll','$phone', '$add')";
	$result=$connect->query($q);
	
	if($result)
		header('location:index.php');

?>