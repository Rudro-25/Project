<?php
	include "dbconnect.php";
	$q="SELECT * FROM student";
	$result=$connect->query($q);

?>

<html>
<head>
	<style>
		table, td, th{
			border-collapse:collapse;
			border: 2px solid black;
		}
		table{
			width: 80%;
		}
	
	</style>
</head>

<body>

	<h1> Student Info</h1>

	<table cellpadding="5" cellspacing="5">
		<tr>
			<th>Name</th>
			<th>Roll</th>
			<th>Phone</th>
			<th>Address</th>
			<th>Edit</th>
			<th>Delete</th>
		</tr>
		
		<?php
		while($row=$result->fetch_assoc())
		{
			$id=$row["id"];
			$name=$row["name"];
			echo "<tr>";
				echo "<td>".$name."</td>";
				echo "<td>".$row["roll"]. " </td>";
				echo "<td>".$row["phone"]. " </td>";
				echo "<td>".$row["address"]. " </td>";
				echo "<td>"."<a href='update.php?editid=$id'>Edit</a>"."</td>";
				echo "<td>"."<a href='delete.php?delid=$id'>Delete</a>"."</td>";
			echo "</tr>";
		}
		
		?>
	</table>
	
	<a href="insert.php">Add Student Record</a>
	
</body>
</html>