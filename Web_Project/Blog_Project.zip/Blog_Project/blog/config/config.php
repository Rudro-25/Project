<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "blog_db");
define("TITLE", "CSE 5th live project");
define("KEYWORDS", "PHP Tutorials, JAVA Tutorials, Oracle Database, C# Tutorials");

