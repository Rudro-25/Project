<?php
  $conn = mysqli_connect('localhost', 'root', '', '18cse025');
?>