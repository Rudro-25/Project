var taxInp = document.getElementById('tax');
var demandchargeInp = document.getElementById('demand-charge');
var unitUsageInp = document.getElementById('unit-usage');
var totalBillSpan = document.getElementById('total-bill');
var a=0,b=0,c=0,d=0;

function calculateBill(unitUsage){
   var bill = 0, curUnit=unitUsage;
   if(curUnit > 100){
   	a = (curUnit-100);
   	bill += a*3;
   	curUnit=100;
   }
   if(curUnit > 80){
   	b = (curUnit-80);
   	bill += b*2.5;
   	curUnit=80;
   }
   if(curUnit > 50){
   	c= (curUnit-50);
   	bill += c*2;
   	curUnit=50;
   }
   d=curUnit;
   bill += curUnit*1.5;

   return bill;
}

function showTotalBill(){
	var tax = Number(taxInp.value);
	var demandcharge = Number(demandchargeInp.value);
	var unitUsage = Number(unitUsageInp.value);

    var bill = calculateBill(unitUsage);
	var totalBill = bill + tax + demandcharge;
	totalBillSpan.innerText = "Total bill : "+ totalBill;
	document.getElementById("show").innerHTML =d+"*1.5+"+c+"*2+"+b+"*2.5+"+a+"*3 = "+ bill;
}

taxInp.addEventListener('input', showTotalBill);
demandchargeInp.addEventListener('input',showTotalBill);
unitUsageInp.addEventListener('input',showTotalBill);